'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable('CustOrganizations', {
            id: {
                allowNull: false,
                autoIncrement: true,
                primaryKey: true,
                type: Sequelize.INTEGER
            },

            name: {
                type: Sequelize.STRING(30)
            },
            street: {
                type: Sequelize.STRING(50)
            },
            street2: {
                type: Sequelize.STRING(15)
            },
            city: {
                type: Sequelize.STRING(21)
            },
            state: {
                type: Sequelize.STRING(2)
            },
            zip: {
                type: Sequelize.INTEGER(5)
            },
            country: {
                type: Sequelize.STRING(3)
            },
            phone: {
                type: Sequelize.INTEGER(11)
            },
            email: {
                type: Sequelize.STRING(25)
            },
            salescontact: {
                type: Sequelize.STRING(11)
            },
            billingcontact: {
                type: Sequelize.STRING(11)
            },
            OrgAccountTypeId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'OrgAccountTypes',
                    key: 'id'
                }
            },
            OrgFarmTypeId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'OrgFarmTypes',
                    key: 'id'
                }
            },
            OrgInvoicingTypeId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'OrgInvoicingTypes',
                    key: 'id'
                }
            },
            OrgMarketId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'OrgMarkets',
                    key: 'id'
                }
            },
            OrgServicePlanTypeId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'OrgServicePlanTypes',
                    key: 'id'
                }
            },
            OrgST101TypeId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'OrgST101Types',
                    key: 'id'
                }
            },

            createdAt: {
                allowNull: false,
                type: Sequelize.DATE
            },
            updatedAt: {
                allowNull: false,
                type: Sequelize.DATE
            }
        });
    },
    down: (queryInterface, Sequelize) => {
        return queryInterface.dropTable('CustOrganizations');
    }
};
