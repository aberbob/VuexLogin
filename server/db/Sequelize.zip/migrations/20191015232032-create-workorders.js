'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable('WorkOrders', {
            id: {
                allowNull: false,
                autoIncrement: true,
                primaryKey: true,
                type: Sequelize.INTEGER
            },

            description: {
                type: Sequelize.STRING(50)
            },
            type: {
                type: Sequelize.STRING(30)
            },
            notes: {
                type: Sequelize.STRING(500)
            },
            EquipmentProfileId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'EquipmentProfiles',
                    key: 'id'
                }
            },
            WOCategoryId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'WOCategories',
                    key: 'id'
                }
            },
            WOStatusId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'WOStatuses',
                    key: 'id'
                }
            },
            CustContactId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'CustContacts',
                    key: 'id'
                }
            },
            CustOrganizationId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'CustOrganizations',
                    key: 'id'
                }
            },
            UserId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'Users',
                    key: 'id'
                }
            },
            WOPriorityId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'WOPriorities',
                    key: 'id'
                }
            },

            createdAt: {
                allowNull: false,
                type: Sequelize.DATE
            },
            updatedAt: {
                allowNull: false,
                type: Sequelize.DATE
            }
        });
    },
    down: (queryInterface, Sequelize) => {
        return queryInterface.dropTable('WorkOrders');
    }
};
