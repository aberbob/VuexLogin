'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable('Transfers', {
            id: {
                allowNull: false,
                autoIncrement: true,
                primaryKey: true,
                type: Sequelize.INTEGER
            },

            CustOrganizationId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'CustOrganizations',
                    key: 'id'
                }
            },
            TransferStatusId: {
                type: Sequelize.INTEGER(11),
                references: {
                    model: 'TransferStatuses',
                    key: 'id'
                }
            },
            notes: {
                type: Sequelize.STRING(100)
            },
            destination: {
                type: Sequelize.STRING(100)
            },
            source: {
                type: Sequelize.STRING(100)
            },

            createdAt: {
                allowNull: false,
                type: Sequelize.DATE
            },
            updatedAt: {
                allowNull: false,
                type: Sequelize.DATE
            }
        });
    },
    down: (queryInterface, Sequelize) => {
        return queryInterface.dropTable('Transfers');
    }
};
